package com.codexbar.android.model

import androidx.compose.ui.graphics.Color

enum class ProviderType {
    CLAUDE, CODEX, CURSOR, GEMINI, COPILOT, OPENROUTER, KIRO, VERTEX_AI, CUSTOM
}

data class UsageWindow(
    val used: Double,
    val total: Double,
    val label: String,         // e.g. "Session", "Weekly", "Monthly"
    val resetsAt: Long? = null // epoch millis
) {
    val fraction: Float get() = if (total > 0) (used / total).coerceIn(0.0, 1.0).toFloat() else 0f
    val usedFormatted: String get() = formatTokens(used)
    val totalFormatted: String get() = formatTokens(total)

    private fun formatTokens(v: Double): String = when {
        v >= 1_000_000 -> "%.1fM".format(v / 1_000_000)
        v >= 1_000 -> "%.1fK".format(v / 1_000)
        else -> "%.0f".format(v)
    }
}

data class ProviderStatus(
    val type: ProviderType,
    val displayName: String,
    val isEnabled: Boolean = true,
    val isLoading: Boolean = false,
    val error: String? = null,
    val sessionWindow: UsageWindow? = null,
    val weeklyWindow: UsageWindow? = null,
    val monthlyWindow: UsageWindow? = null,
    val creditsRemaining: Double? = null,
    val totalCostUsd: Double? = null,
    val lastRefreshed: Long = System.currentTimeMillis(),
    val incidentMessage: String? = null
) {
    val primaryColor: Color get() = when (type) {
        ProviderType.CLAUDE    -> Color(0xFFD97706)
        ProviderType.CODEX     -> Color(0xFF10B981)
        ProviderType.CURSOR    -> Color(0xFF6366F1)
        ProviderType.GEMINI    -> Color(0xFF3B82F6)
        ProviderType.COPILOT   -> Color(0xFF8B5CF6)
        ProviderType.OPENROUTER -> Color(0xFFEC4899)
        ProviderType.KIRO      -> Color(0xFFF59E0B)
        ProviderType.VERTEX_AI -> Color(0xFF0EA5E9)
        ProviderType.CUSTOM    -> Color(0xFF64748B)
    }

    val icon: String get() = when (type) {
        ProviderType.CLAUDE     -> "🤖"
        ProviderType.CODEX      -> "⚡"
        ProviderType.CURSOR     -> "✦"
        ProviderType.GEMINI     -> "♊"
        ProviderType.COPILOT    -> "🐙"
        ProviderType.OPENROUTER -> "🔀"
        ProviderType.KIRO       -> "🪁"
        ProviderType.VERTEX_AI  -> "🔷"
        ProviderType.CUSTOM     -> "🔧"
    }

    val primaryWindow: UsageWindow? get() = sessionWindow ?: weeklyWindow ?: monthlyWindow
}

data class ProviderConfig(
    val type: ProviderType,
    val enabled: Boolean = false,
    val apiKey: String = "",
    val sessionToken: String = "",
    val extraParam: String = ""
)
