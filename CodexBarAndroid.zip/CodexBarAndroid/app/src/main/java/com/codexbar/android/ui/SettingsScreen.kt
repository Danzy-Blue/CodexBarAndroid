package com.codexbar.android.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codexbar.android.model.ProviderConfig
import com.codexbar.android.model.ProviderStatus
import com.codexbar.android.model.ProviderType

data class ProviderMeta(
    val type: ProviderType,
    val name: String,
    val icon: String,
    val apiKeyLabel: String?,
    val tokenLabel: String?,
    val extraLabel: String?,
    val helpText: String
)

private val PROVIDER_META = listOf(
    ProviderMeta(ProviderType.CLAUDE, "Claude", "🤖",
        apiKeyLabel = "Anthropic API Key",
        tokenLabel = null,
        extraLabel = null,
        helpText = "Get your API key from console.anthropic.com"),
    ProviderMeta(ProviderType.CODEX, "OpenAI Codex", "⚡",
        apiKeyLabel = "OpenAI API Key",
        tokenLabel = null,
        extraLabel = null,
        helpText = "Get your key from platform.openai.com/api-keys"),
    ProviderMeta(ProviderType.CURSOR, "Cursor", "✦",
        apiKeyLabel = null,
        tokenLabel = "Session Token (WorkosCursorSessionToken cookie)",
        extraLabel = null,
        helpText = "Sign in to cursor.com, copy the WorkosCursorSessionToken cookie value"),
    ProviderMeta(ProviderType.GEMINI, "Gemini", "♊",
        apiKeyLabel = "Google API Key",
        tokenLabel = null,
        extraLabel = null,
        helpText = "Get your key from aistudio.google.com/apikey"),
    ProviderMeta(ProviderType.COPILOT, "GitHub Copilot", "🐙",
        apiKeyLabel = "GitHub Personal Access Token",
        tokenLabel = null,
        extraLabel = null,
        helpText = "Create a fine-grained PAT at github.com/settings/tokens with Copilot scope"),
    ProviderMeta(ProviderType.OPENROUTER, "OpenRouter", "🔀",
        apiKeyLabel = "OpenRouter API Key",
        tokenLabel = null,
        extraLabel = null,
        helpText = "Get your key from openrouter.ai/settings/keys"),
    ProviderMeta(ProviderType.KIRO, "Kiro", "🪁",
        apiKeyLabel = "Kiro API Key",
        tokenLabel = null,
        extraLabel = null,
        helpText = "Get your key from kiro.dev — limited Android support"),
    ProviderMeta(ProviderType.VERTEX_AI, "Vertex AI", "🔷",
        apiKeyLabel = "OAuth Access Token",
        tokenLabel = null,
        extraLabel = "GCP Project ID",
        helpText = "Run: gcloud auth print-access-token — expires hourly"),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    configs: Map<ProviderType, ProviderConfig>,
    onConfigChange: (ProviderConfig) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(
                start = 16.dp, end = 16.dp,
                top = padding.calculateTopPadding() + 8.dp,
                bottom = 32.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    "PROVIDERS",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            items(PROVIDER_META, key = { it.type.name }) { meta ->
                val config = configs[meta.type] ?: ProviderConfig(type = meta.type)
                ProviderConfigCard(
                    meta = meta,
                    config = config,
                    onConfigChange = onConfigChange
                )
            }
            item {
                Spacer(Modifier.height(8.dp))
                Text(
                    "ABOUT",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item {
                AboutCard()
            }
        }
    }
}

@Composable
fun ProviderConfigCard(
    meta: ProviderMeta,
    config: ProviderConfig,
    onConfigChange: (ProviderConfig) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(meta.icon, fontSize = 20.sp)
                    Spacer(Modifier.width(12.dp))
                    Text(meta.name, fontWeight = FontWeight.SemiBold)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = config.enabled,
                        onCheckedChange = { enabled ->
                            onConfigChange(config.copy(enabled = enabled))
                            if (enabled) expanded = true
                        }
                    )
                    Spacer(Modifier.width(4.dp))
                    IconButton(onClick = { expanded = !expanded }) {
                        Icon(
                            if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = if (expanded) "Collapse" else "Expand"
                        )
                    }
                }
            }

            if (expanded) {
                Spacer(Modifier.height(12.dp))
                Divider()
                Spacer(Modifier.height(12.dp))

                // Help text
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.Top) {
                        Icon(Icons.Default.Info, null,
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onSecondaryContainer)
                        Spacer(Modifier.width(8.dp))
                        Text(meta.helpText,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer)
                    }
                }
                Spacer(Modifier.height(12.dp))

                // API Key field
                if (meta.apiKeyLabel != null) {
                    var showKey by remember { mutableStateOf(false) }
                    OutlinedTextField(
                        value = config.apiKey,
                        onValueChange = { onConfigChange(config.copy(apiKey = it)) },
                        label = { Text(meta.apiKeyLabel) },
                        singleLine = true,
                        visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            IconButton(onClick = { showKey = !showKey }) {
                                Icon(
                                    if (showKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = if (showKey) "Hide" else "Show"
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                }

                // Session token field
                if (meta.tokenLabel != null) {
                    var showToken by remember { mutableStateOf(false) }
                    OutlinedTextField(
                        value = config.sessionToken,
                        onValueChange = { onConfigChange(config.copy(sessionToken = it)) },
                        label = { Text(meta.tokenLabel) },
                        singleLine = false,
                        minLines = 2,
                        maxLines = 4,
                        visualTransformation = if (showToken) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showToken = !showToken }) {
                                Icon(
                                    if (showToken) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = null
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                }

                // Extra field
                if (meta.extraLabel != null) {
                    OutlinedTextField(
                        value = config.extraParam,
                        onValueChange = { onConfigChange(config.copy(extraParam = it)) },
                        label = { Text(meta.extraLabel) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
fun AboutCard() {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("CodexBar Android", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Android port of CodexBar by steipete. Shows AI coding tool usage stats.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Original project: github.com/steipete/CodexBar",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "License: MIT",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
