package com.codexbar.android.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.codexbar.android.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.abs

val Context.dataStore by preferencesDataStore(name = "provider_configs")

class ProviderRepository(private val context: Context) {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    // ---------- Config persistence ----------

    fun getConfigFlow(type: ProviderType): Flow<ProviderConfig> {
        val keyEnabled = stringPreferencesKey("${type.name}_enabled")
        val keyApi = stringPreferencesKey("${type.name}_api_key")
        val keyToken = stringPreferencesKey("${type.name}_token")
        val keyExtra = stringPreferencesKey("${type.name}_extra")
        return context.dataStore.data.map { prefs ->
            ProviderConfig(
                type = type,
                enabled = prefs[keyEnabled] == "true",
                apiKey = prefs[keyApi] ?: "",
                sessionToken = prefs[keyToken] ?: "",
                extraParam = prefs[keyExtra] ?: ""
            )
        }
    }

    suspend fun saveConfig(config: ProviderConfig) {
        val keyEnabled = stringPreferencesKey("${config.type.name}_enabled")
        val keyApi = stringPreferencesKey("${config.type.name}_api_key")
        val keyToken = stringPreferencesKey("${config.type.name}_token")
        val keyExtra = stringPreferencesKey("${config.type.name}_extra")
        context.dataStore.edit { prefs ->
            prefs[keyEnabled] = if (config.enabled) "true" else "false"
            prefs[keyApi] = config.apiKey
            prefs[keyToken] = config.sessionToken
            prefs[keyExtra] = config.extraParam
        }
    }

    // ---------- Provider fetchers ----------

    suspend fun fetchClaudeUsage(config: ProviderConfig): ProviderStatus = withContext(Dispatchers.IO) {
        if (!config.enabled) return@withContext disabledStatus(ProviderType.CLAUDE, "Claude")
        if (config.apiKey.isBlank() && config.sessionToken.isBlank()) {
            return@withContext ProviderStatus(
                type = ProviderType.CLAUDE, displayName = "Claude",
                error = "No API key or session token configured"
            )
        }
        try {
            // Claude Code usage endpoint
            val req = Request.Builder()
                .url("https://api.anthropic.com/v1/usage")
                .header("x-api-key", config.apiKey)
                .header("anthropic-version", "2023-06-01")
                .build()
            val resp = httpClient.newCall(req).execute()
            if (!resp.isSuccessful) {
                return@withContext ProviderStatus(
                    type = ProviderType.CLAUDE, displayName = "Claude",
                    error = "HTTP ${resp.code}: ${resp.message}"
                )
            }
            val body = resp.body?.string() ?: "{}"
            val json = JSONObject(body)
            // Parse response — Anthropic returns billing/usage info
            val inputTokens = json.optLong("input_tokens", 0)
            val outputTokens = json.optLong("output_tokens", 0)
            val totalTokens = inputTokens + outputTokens
            // Claude Pro has ~5M tokens/session window approx
            val sessionLimit = 5_000_000.0
            ProviderStatus(
                type = ProviderType.CLAUDE,
                displayName = "Claude",
                sessionWindow = UsageWindow(totalTokens.toDouble(), sessionLimit, "Session"),
            )
        } catch (e: Exception) {
            ProviderStatus(
                type = ProviderType.CLAUDE, displayName = "Claude",
                error = "Failed: ${e.message?.take(60)}"
            )
        }
    }

    suspend fun fetchOpenRouterUsage(config: ProviderConfig): ProviderStatus = withContext(Dispatchers.IO) {
        if (!config.enabled) return@withContext disabledStatus(ProviderType.OPENROUTER, "OpenRouter")
        if (config.apiKey.isBlank()) {
            return@withContext ProviderStatus(
                type = ProviderType.OPENROUTER, displayName = "OpenRouter",
                error = "No API key configured"
            )
        }
        try {
            val req = Request.Builder()
                .url("https://openrouter.ai/api/v1/auth/key")
                .header("Authorization", "Bearer ${config.apiKey}")
                .build()
            val resp = httpClient.newCall(req).execute()
            if (!resp.isSuccessful) {
                return@withContext ProviderStatus(
                    type = ProviderType.OPENROUTER, displayName = "OpenRouter",
                    error = "HTTP ${resp.code}"
                )
            }
            val json = JSONObject(resp.body?.string() ?: "{}")
            val data = json.optJSONObject("data") ?: json
            val limit = data.optDouble("limit", 0.0)
            val usage = data.optDouble("usage", 0.0)
            val remaining = if (limit > 0) limit - usage else data.optDouble("limit_remaining", 0.0)
            ProviderStatus(
                type = ProviderType.OPENROUTER,
                displayName = "OpenRouter",
                creditsRemaining = remaining,
                monthlyWindow = if (limit > 0) UsageWindow(usage, limit, "Credits") else null
            )
        } catch (e: Exception) {
            ProviderStatus(
                type = ProviderType.OPENROUTER, displayName = "OpenRouter",
                error = "Failed: ${e.message?.take(60)}"
            )
        }
    }

    suspend fun fetchCopilotUsage(config: ProviderConfig): ProviderStatus = withContext(Dispatchers.IO) {
        if (!config.enabled) return@withContext disabledStatus(ProviderType.COPILOT, "Copilot")
        if (config.apiKey.isBlank()) {
            return@withContext ProviderStatus(
                type = ProviderType.COPILOT, displayName = "GitHub Copilot",
                error = "No GitHub token configured"
            )
        }
        try {
            val req = Request.Builder()
                .url("https://api.github.com/copilot_internal/user")
                .header("Authorization", "token ${config.apiKey}")
                .header("Accept", "application/vnd.github.v3+json")
                .build()
            val resp = httpClient.newCall(req).execute()
            if (!resp.isSuccessful) {
                return@withContext ProviderStatus(
                    type = ProviderType.COPILOT, displayName = "GitHub Copilot",
                    error = "HTTP ${resp.code}"
                )
            }
            val json = JSONObject(resp.body?.string() ?: "{}")
            val planType = json.optString("copilot_plan", "unknown")
            val chat = json.optJSONObject("copilot_chat")
            val chatEnabled = chat?.optBoolean("enabled", false) ?: false
            ProviderStatus(
                type = ProviderType.COPILOT,
                displayName = "GitHub Copilot",
                sessionWindow = if (chatEnabled) UsageWindow(0.0, 1.0, "Chat Active") else null,
                incidentMessage = "Plan: $planType"
            )
        } catch (e: Exception) {
            ProviderStatus(
                type = ProviderType.COPILOT, displayName = "GitHub Copilot",
                error = "Failed: ${e.message?.take(60)}"
            )
        }
    }

    suspend fun fetchGeminiUsage(config: ProviderConfig): ProviderStatus = withContext(Dispatchers.IO) {
        if (!config.enabled) return@withContext disabledStatus(ProviderType.GEMINI, "Gemini")
        if (config.apiKey.isBlank()) {
            return@withContext ProviderStatus(
                type = ProviderType.GEMINI, displayName = "Gemini",
                error = "No API key configured"
            )
        }
        try {
            // Use Gemini models endpoint to verify key is valid
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models?key=${config.apiKey}&pageSize=1")
                .build()
            val resp = httpClient.newCall(req).execute()
            if (!resp.isSuccessful) {
                return@withContext ProviderStatus(
                    type = ProviderType.GEMINI, displayName = "Gemini",
                    error = "HTTP ${resp.code}: invalid key?"
                )
            }
            // Gemini doesn't expose usage stats directly via public API
            // Show key is valid + daily quota info
            ProviderStatus(
                type = ProviderType.GEMINI,
                displayName = "Gemini",
                sessionWindow = UsageWindow(0.0, 1500.0, "Daily Requests"),
                incidentMessage = "API key valid — quota not directly accessible"
            )
        } catch (e: Exception) {
            ProviderStatus(
                type = ProviderType.GEMINI, displayName = "Gemini",
                error = "Failed: ${e.message?.take(60)}"
            )
        }
    }

    suspend fun fetchCursorUsage(config: ProviderConfig): ProviderStatus = withContext(Dispatchers.IO) {
        if (!config.enabled) return@withContext disabledStatus(ProviderType.CURSOR, "Cursor")
        if (config.sessionToken.isBlank()) {
            return@withContext ProviderStatus(
                type = ProviderType.CURSOR, displayName = "Cursor",
                error = "No session token — see Settings"
            )
        }
        try {
            val req = Request.Builder()
                .url("https://www.cursor.com/api/usage")
                .header("Cookie", "WorkosCursorSessionToken=${config.sessionToken}")
                .header("User-Agent", "CodexBarAndroid/1.0")
                .build()
            val resp = httpClient.newCall(req).execute()
            if (!resp.isSuccessful) {
                return@withContext ProviderStatus(
                    type = ProviderType.CURSOR, displayName = "Cursor",
                    error = "HTTP ${resp.code}: session expired?"
                )
            }
            val json = JSONObject(resp.body?.string() ?: "{}")
            // Parse Cursor usage fields
            val gpt4Used = json.optInt("gpt-4", 0)
            val gpt4Total = json.optInt("gpt-4-max", 500)
            val fastUsed = json.optInt("fast-premium-requests-used", gpt4Used)
            val fastTotal = json.optInt("fast-premium-requests-allowed", gpt4Total)
            val slowUnlimited = json.optBoolean("slow-requests-unlimited", false)
            ProviderStatus(
                type = ProviderType.CURSOR,
                displayName = "Cursor",
                monthlyWindow = UsageWindow(fastUsed.toDouble(), fastTotal.toDouble(), "Fast Requests"),
                incidentMessage = if (slowUnlimited) "Slow requests: unlimited" else null
            )
        } catch (e: Exception) {
            ProviderStatus(
                type = ProviderType.CURSOR, displayName = "Cursor",
                error = "Failed: ${e.message?.take(60)}"
            )
        }
    }

    suspend fun fetchCodexUsage(config: ProviderConfig): ProviderStatus = withContext(Dispatchers.IO) {
        if (!config.enabled) return@withContext disabledStatus(ProviderType.CODEX, "Codex")
        if (config.apiKey.isBlank()) {
            return@withContext ProviderStatus(
                type = ProviderType.CODEX, displayName = "OpenAI Codex",
                error = "No API key configured"
            )
        }
        try {
            val req = Request.Builder()
                .url("https://api.openai.com/v1/usage?date=${todayDate()}")
                .header("Authorization", "Bearer ${config.apiKey}")
                .build()
            val resp = httpClient.newCall(req).execute()
            if (!resp.isSuccessful) {
                return@withContext ProviderStatus(
                    type = ProviderType.CODEX, displayName = "OpenAI Codex",
                    error = "HTTP ${resp.code}"
                )
            }
            val json = JSONObject(resp.body?.string() ?: "{}")
            val data = json.optJSONArray("data")
            var totalCost = 0.0
            if (data != null) {
                for (i in 0 until data.length()) {
                    val item = data.getJSONObject(i)
                    totalCost += item.optDouble("total_usage", 0.0) / 100.0 // cents to dollars
                }
            }
            ProviderStatus(
                type = ProviderType.CODEX,
                displayName = "OpenAI Codex",
                totalCostUsd = totalCost,
                sessionWindow = UsageWindow(totalCost, 100.0, "Daily Cost ($)")
            )
        } catch (e: Exception) {
            ProviderStatus(
                type = ProviderType.CODEX, displayName = "OpenAI Codex",
                error = "Failed: ${e.message?.take(60)}"
            )
        }
    }

    suspend fun fetchKiroUsage(config: ProviderConfig): ProviderStatus = withContext(Dispatchers.IO) {
        if (!config.enabled) return@withContext disabledStatus(ProviderType.KIRO, "Kiro")
        if (config.apiKey.isBlank()) {
            return@withContext ProviderStatus(
                type = ProviderType.KIRO, displayName = "Kiro",
                error = "No API key configured — see kiro.dev"
            )
        }
        // Kiro doesn't have a public API yet - return placeholder
        ProviderStatus(
            type = ProviderType.KIRO,
            displayName = "Kiro",
            incidentMessage = "Kiro CLI integration not available on Android yet"
        )
    }

    suspend fun fetchVertexUsage(config: ProviderConfig): ProviderStatus = withContext(Dispatchers.IO) {
        if (!config.enabled) return@withContext disabledStatus(ProviderType.VERTEX_AI, "Vertex AI")
        if (config.apiKey.isBlank()) {
            return@withContext ProviderStatus(
                type = ProviderType.VERTEX_AI, displayName = "Vertex AI",
                error = "No API key configured"
            )
        }
        try {
            val projectId = config.extraParam.ifBlank { "my-project" }
            val req = Request.Builder()
                .url("https://monitoring.googleapis.com/v3/projects/$projectId/timeSeries?filter=metric.type%3D%22aiplatform.googleapis.com%2Fprediction%2Fonline%2Frequest_count%22")
                .header("Authorization", "Bearer ${config.apiKey}")
                .build()
            val resp = httpClient.newCall(req).execute()
            if (!resp.isSuccessful) {
                return@withContext ProviderStatus(
                    type = ProviderType.VERTEX_AI, displayName = "Vertex AI",
                    error = "HTTP ${resp.code}: check project ID and token"
                )
            }
            ProviderStatus(
                type = ProviderType.VERTEX_AI,
                displayName = "Vertex AI",
                incidentMessage = "Connected — detailed metrics via GCP Console"
            )
        } catch (e: Exception) {
            ProviderStatus(
                type = ProviderType.VERTEX_AI, displayName = "Vertex AI",
                error = "Failed: ${e.message?.take(60)}"
            )
        }
    }

    private fun disabledStatus(type: ProviderType, name: String) = ProviderStatus(
        type = type, displayName = name, isEnabled = false
    )

    private fun todayDate(): String {
        val cal = java.util.Calendar.getInstance()
        return "%d-%02d-%02d".format(cal.get(java.util.Calendar.YEAR),
            cal.get(java.util.Calendar.MONTH) + 1, cal.get(java.util.Calendar.DAY_OF_MONTH))
    }
}
