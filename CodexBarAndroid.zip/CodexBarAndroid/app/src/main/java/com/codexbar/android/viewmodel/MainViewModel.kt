package com.codexbar.android.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.codexbar.android.data.ProviderRepository
import com.codexbar.android.model.ProviderConfig
import com.codexbar.android.model.ProviderStatus
import com.codexbar.android.model.ProviderType
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

data class MainUiState(
    val providers: List<ProviderStatus> = emptyList(),
    val isRefreshing: Boolean = false,
    val lastRefreshed: Long = 0L,
    val configs: Map<ProviderType, ProviderConfig> = emptyMap()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = ProviderRepository(application)

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private var autoRefreshJob: Job? = null

    init {
        loadConfigs()
        startAutoRefresh()
    }

    private fun loadConfigs() {
        viewModelScope.launch {
            // Collect configs for all provider types
            val configFlows = ProviderType.values().map { type ->
                repo.getConfigFlow(type).map { type to it }
            }
            combine(configFlows) { pairs -> pairs.toMap() }
                .collect { configs ->
                    _uiState.update { it.copy(configs = configs) }
                    refresh()
                }
        }
    }

    private fun startAutoRefresh() {
        autoRefreshJob?.cancel()
        autoRefreshJob = viewModelScope.launch {
            while (isActive) {
                delay(120_000L) // auto-refresh every 2 minutes
                refresh()
            }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.update { it.copy(isRefreshing = true) }
            val configs = _uiState.value.configs
            val results = fetchAll(configs)
            _uiState.update { state ->
                state.copy(
                    providers = results,
                    isRefreshing = false,
                    lastRefreshed = System.currentTimeMillis()
                )
            }
        }
    }

    private suspend fun fetchAll(configs: Map<ProviderType, ProviderConfig>): List<ProviderStatus> {
        return coroutineScope {
            val deferred = listOf(
                async { repo.fetchClaudeUsage(configs[ProviderType.CLAUDE] ?: defaultConfig(ProviderType.CLAUDE)) },
                async { repo.fetchCodexUsage(configs[ProviderType.CODEX] ?: defaultConfig(ProviderType.CODEX)) },
                async { repo.fetchCursorUsage(configs[ProviderType.CURSOR] ?: defaultConfig(ProviderType.CURSOR)) },
                async { repo.fetchGeminiUsage(configs[ProviderType.GEMINI] ?: defaultConfig(ProviderType.GEMINI)) },
                async { repo.fetchCopilotUsage(configs[ProviderType.COPILOT] ?: defaultConfig(ProviderType.COPILOT)) },
                async { repo.fetchOpenRouterUsage(configs[ProviderType.OPENROUTER] ?: defaultConfig(ProviderType.OPENROUTER)) },
                async { repo.fetchKiroUsage(configs[ProviderType.KIRO] ?: defaultConfig(ProviderType.KIRO)) },
                async { repo.fetchVertexUsage(configs[ProviderType.VERTEX_AI] ?: defaultConfig(ProviderType.VERTEX_AI)) },
            )
            deferred.awaitAll()
        }
    }

    fun updateConfig(config: ProviderConfig) {
        viewModelScope.launch {
            repo.saveConfig(config)
        }
    }

    private fun defaultConfig(type: ProviderType) = ProviderConfig(type = type, enabled = false)
}
