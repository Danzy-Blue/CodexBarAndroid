package com.codexbar.android.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codexbar.android.model.ProviderStatus
import com.codexbar.android.model.UsageWindow
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    providers: List<ProviderStatus>,
    isRefreshing: Boolean,
    lastRefreshed: Long,
    onRefresh: () -> Unit,
    onSettingsClick: () -> Unit
) {
    val enabledProviders = providers.filter { it.isEnabled }
    val disabledProviders = providers.filter { !it.isEnabled }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "🎚️ CodexBar",
                            fontWeight = FontWeight.Bold,
                            fontSize = 22.sp
                        )
                    }
                },
                actions = {
                    if (isRefreshing) {
                        val rotation by rememberInfiniteTransition(label = "spin").animateFloat(
                            0f, 360f, infiniteRepeatable(tween(1000, easing = LinearEasing)), label = "rot"
                        )
                        Icon(
                            Icons.Default.Refresh,
                            contentDescription = null,
                            modifier = Modifier.padding(8.dp).rotate(rotation)
                        )
                    } else {
                        IconButton(onClick = onRefresh) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                        }
                    }
                    IconButton(onClick = onSettingsClick) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(
                start = 16.dp, end = 16.dp,
                top = padding.calculateTopPadding() + 8.dp,
                bottom = padding.calculateBottomPadding() + 16.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Last refreshed chip
            if (lastRefreshed > 0) {
                item {
                    val fmt = remember { SimpleDateFormat("h:mm:ss a", Locale.getDefault()) }
                    Text(
                        "Updated ${fmt.format(Date(lastRefreshed))}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }
            }

            if (enabledProviders.isEmpty() && !isRefreshing) {
                item { EmptyState(onSettingsClick) }
            }

            items(enabledProviders, key = { it.type.name }) { provider ->
                ProviderCard(provider)
            }

            if (disabledProviders.isNotEmpty()) {
                item {
                    Text(
                        "DISABLED PROVIDERS",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                items(disabledProviders, key = { it.type.name + "_disabled" }) { provider ->
                    DisabledProviderRow(provider, onSettingsClick)
                }
            }
        }
    }
}

@Composable
fun ProviderCard(status: ProviderStatus) {
    val color = status.primaryColor
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Colored dot
                    Box(
                        Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(color.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(status.icon, fontSize = 18.sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(status.displayName, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        if (status.incidentMessage != null) {
                            Text(
                                status.incidentMessage,
                                style = MaterialTheme.typography.labelSmall,
                                color = color,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
                // Status indicator
                if (status.error != null) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(20.dp))
                } else if (status.isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF22C55E), modifier = Modifier.size(20.dp))
                }
            }

            // Error message
            if (status.error != null) {
                Spacer(Modifier.height(8.dp))
                Surface(
                    color = Color(0xFFEF4444).copy(alpha = 0.1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        status.error,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFEF4444),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
                return@Column
            }

            Spacer(Modifier.height(12.dp))

            // Usage windows
            val windows = listOfNotNull(status.sessionWindow, status.weeklyWindow, status.monthlyWindow)
            if (windows.isEmpty() && status.creditsRemaining != null) {
                CreditsRow(status.creditsRemaining, color)
            } else {
                windows.forEachIndexed { idx, window ->
                    if (idx > 0) Spacer(Modifier.height(10.dp))
                    UsageMeter(window, color)
                }
            }

            // Cost info
            if (status.totalCostUsd != null) {
                Spacer(Modifier.height(8.dp))
                Row {
                    Icon(Icons.Default.AttachMoney, null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        "Today: ${"$%.4f".format(status.totalCostUsd)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun UsageMeter(window: UsageWindow, color: Color) {
    val animFraction by animateFloatAsState(
        targetValue = window.fraction,
        animationSpec = tween(800, easing = FastOutSlowInEasing),
        label = "meter"
    )

    Column {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(window.label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Medium)
            Text(
                "${window.usedFormatted} / ${window.totalFormatted}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(6.dp))

        // Track
        Box(
            Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            // Fill
            Box(
                Modifier
                    .fillMaxWidth(animFraction)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(color.copy(alpha = 0.7f), color)
                        )
                    )
            )
        }

        // Percentage
        Spacer(Modifier.height(3.dp))
        Text(
            "${(window.fraction * 100).roundToInt()}% used",
            style = MaterialTheme.typography.labelSmall,
            color = if (window.fraction > 0.85f) Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun CreditsRow(credits: Double, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.AccountBalanceWallet, null, tint = color, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            "Credits remaining: ${"$%.4f".format(credits)}",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun DisabledProviderRow(status: ProviderStatus, onSettingsClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onSettingsClick() }
            .padding(vertical = 8.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(status.icon, fontSize = 16.sp)
            Spacer(Modifier.width(12.dp))
            Text(
                status.displayName,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Text(
            "Enable →",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
fun EmptyState(onSettingsClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🎚️", fontSize = 56.sp)
        Spacer(Modifier.height(16.dp))
        Text(
            "No providers enabled",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Tap Settings to configure your AI tools",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(20.dp))
        Button(onClick = onSettingsClick) {
            Icon(Icons.Default.Settings, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Open Settings")
        }
    }
}
