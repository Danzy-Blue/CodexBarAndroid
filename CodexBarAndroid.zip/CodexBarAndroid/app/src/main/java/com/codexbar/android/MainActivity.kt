package com.codexbar.android

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.codexbar.android.ui.CodexBarTheme
import com.codexbar.android.ui.MainScreen
import com.codexbar.android.ui.SettingsScreen
import com.codexbar.android.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CodexBarTheme {
                val uiState by viewModel.uiState.collectAsState()
                var showSettings by remember { mutableStateOf(false) }

                if (showSettings) {
                    SettingsScreen(
                        configs = uiState.configs,
                        onConfigChange = viewModel::updateConfig,
                        onBack = {
                            showSettings = false
                            viewModel.refresh()
                        }
                    )
                } else {
                    MainScreen(
                        providers = uiState.providers,
                        isRefreshing = uiState.isRefreshing,
                        lastRefreshed = uiState.lastRefreshed,
                        onRefresh = viewModel::refresh,
                        onSettingsClick = { showSettings = true }
                    )
                }
            }
        }
    }
}
