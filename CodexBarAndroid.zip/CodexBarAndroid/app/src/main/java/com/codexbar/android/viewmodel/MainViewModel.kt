package com.codexbar.android.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.codexbar.android.data.ProviderRepository
import com.codexbar.android.model.ProviderConfig
import com.codexbar.android.model.ProviderStatus
import com.codexbar.android.model.ProviderType
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

data class MainUiState(
    val providers: List<ProviderStatus> = emptyList(),
    val isRefreshing: Boolean = false,
    val lastRefreshed: Long = 0L,
    val configs: Map<ProviderType, ProviderConfig> = emptyMap()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = ProviderRepository(application)
    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()
    private val configCache = mutableMapOf<ProviderType, ProviderConfig>()

    init {
        ProviderType.values().forEach { type ->
            viewModelScope.launch {
                try {
                    repo.getConfigFlow(type).collect { config ->
                        configCache[type] = config
                        _uiState.update { it.copy(configs = configCache.toMap()) }
                    }
                } catch (e: Exception) {
                    Log.e("CodexBar", "Config load error for $type", e)
                }
            }
        }
        viewModelScope.launch {
            delay(500)
            refresh()
            while (isActive) {
                delay(120_000L)
                refresh()
            }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            try {
                _uiState.update { it.copy(isRefreshing = true) }
                val results = fetchAll(configCache.toMap())
                _uiState.update { it.copy(providers = results, isRefreshing = false, lastRefreshed = System.currentTimeMillis()) }
            } catch (e: Exception) {
                Log.e("CodexBar", "Refresh error", e)
                _uiState.update { it.copy(isRefreshing = false) }
            }
        }
    }

    private suspend fun fetchAll(configs: Map<ProviderType, ProviderConfig>): List<ProviderStatus> {
        return coroutineScope {
            listOf(
                async { safe { repo.fetchClaudeUsage(configs.def(ProviderType.CLAUDE)) } },
                async { safe { repo.fetchCodexUsage(configs.def(ProviderType.CODEX)) } },
                async { safe { repo.fetchCursorUsage(configs.def(ProviderType.CURSOR)) } },
                async { safe { repo.fetchGeminiUsage(configs.def(ProviderType.GEMINI)) } },
                async { safe { repo.fetchCopilotUsage(configs.def(ProviderType.COPILOT)) } },
                async { safe { repo.fetchOpenRouterUsage(configs.def(ProviderType.OPENROUTER)) } },
                async { safe { repo.fetchKiroUsage(configs.def(ProviderType.KIRO)) } },
                async { safe { repo.fetchVertexUsage(configs.def(ProviderType.VERTEX_AI)) } },
            ).awaitAll()
        }
    }

    private suspend fun safe(block: suspend () -> ProviderStatus): ProviderStatus {
        return try { block() } catch (e: Exception) {
            ProviderStatus(type = ProviderType.CUSTOM, displayName = "Error", error = e.message?.take(80))
        }
    }

    fun updateConfig(config: ProviderConfig) {
        viewModelScope.launch {
            try {
                configCache[config.type] = config
                _uiState.update { it.copy(configs = configCache.toMap()) }
                repo.saveConfig(config)
            } catch (e: Exception) { Log.e("CodexBar", "Save error", e) }
        }
    }

    private fun Map<ProviderType, ProviderConfig>.def(type: ProviderType) =
        this[type] ?: ProviderConfig(type = type, enabled = false)
}
